"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Shield, AlertTriangle, CheckCircle, Loader2 } from "lucide-react"

interface DetectionResult {
  url: string
  isPhishing: boolean
  confidence: number
  features: {
    urlLength: number
    domainLength: number
    hasHttps: boolean
    hasSubdomains: number
    hasSuspiciousKeywords: boolean
    hasIpAddress: boolean
  }
  riskFactors: string[]
}

export default function PhishingDetector() {
  const [url, setUrl] = useState("")
  const [result, setResult] = useState<DetectionResult | null>(null)
  const [loading, setLoading] = useState(false)

  const analyzeUrl = async () => {
    if (!url.trim()) return

    setLoading(true)
    try {
      const response = await fetch("/api/detect-phishing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: url.trim() }),
      })

      const data = await response.json()
      setResult(data)
    } catch (error) {
      console.error("Detection failed:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    analyzeUrl()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4 pt-8">
          <div className="flex items-center justify-center gap-3">
            <Shield className="h-12 w-12 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">Phishing Link Detector</h1>
          </div>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Protect yourself from malicious websites. Our AI-powered system analyzes URLs to detect potential phishing
            attempts.
          </p>
        </div>

        {/* URL Input */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              URL Analysis
            </CardTitle>
            <CardDescription>Enter a URL to check if it's potentially malicious or safe</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex gap-2">
                <Input
                  type="url"
                  placeholder="https://example.com"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="flex-1"
                  disabled={loading}
                />
                <Button type="submit" disabled={loading || !url.trim()}>
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      Analyzing...
                    </>
                  ) : (
                    "Analyze URL"
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Results */}
        {result && (
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {result.isPhishing ? (
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                ) : (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                )}
                Detection Results
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Main Result */}
              <Alert
                className={
                  result.isPhishing
                    ? "border-red-200 bg-red-50 dark:bg-red-950"
                    : "border-green-200 bg-green-50 dark:bg-green-950"
                }
              >
                <AlertDescription className="flex items-center justify-between">
                  <div>
                    <strong
                      className={
                        result.isPhishing ? "text-red-700 dark:text-red-300" : "text-green-700 dark:text-green-300"
                      }
                    >
                      {result.isPhishing ? "POTENTIALLY MALICIOUS" : "APPEARS SAFE"}
                    </strong>
                    <p className="text-sm mt-1">Confidence: {(result.confidence * 100).toFixed(1)}%</p>
                  </div>
                  <Badge variant={result.isPhishing ? "destructive" : "default"}>
                    {result.isPhishing ? "High Risk" : "Low Risk"}
                  </Badge>
                </AlertDescription>
              </Alert>

              {/* URL Info */}
              <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Analyzed URL:</h4>
                <p className="text-sm font-mono break-all bg-white dark:bg-gray-900 p-2 rounded border">{result.url}</p>
              </div>

              {/* Features Analysis */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-3">URL Features</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>URL Length:</span>
                      <span className={result.features.urlLength > 100 ? "text-red-600" : "text-green-600"}>
                        {result.features.urlLength} chars
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Domain Length:</span>
                      <span className={result.features.domainLength > 30 ? "text-red-600" : "text-green-600"}>
                        {result.features.domainLength} chars
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>HTTPS:</span>
                      <span className={result.features.hasHttps ? "text-green-600" : "text-red-600"}>
                        {result.features.hasHttps ? "Yes" : "No"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Subdomains:</span>
                      <span className={result.features.hasSubdomains > 3 ? "text-red-600" : "text-green-600"}>
                        {result.features.hasSubdomains}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Suspicious Keywords:</span>
                      <span className={result.features.hasSuspiciousKeywords ? "text-red-600" : "text-green-600"}>
                        {result.features.hasSuspiciousKeywords ? "Found" : "None"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>IP Address:</span>
                      <span className={result.features.hasIpAddress ? "text-red-600" : "text-green-600"}>
                        {result.features.hasIpAddress ? "Yes" : "No"}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Risk Factors */}
                <div>
                  <h4 className="font-semibold mb-3">Risk Factors</h4>
                  {result.riskFactors.length > 0 ? (
                    <div className="space-y-2">
                      {result.riskFactors.map((factor, index) => (
                        <div key={index} className="flex items-start gap-2">
                          <AlertTriangle className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-red-700 dark:text-red-300">{factor}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-green-600">No significant risk factors detected</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Info Section */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>How It Works</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mx-auto">
                  <Shield className="h-6 w-6 text-blue-600" />
                </div>
                <h4 className="font-semibold">Feature Extraction</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  Analyzes URL structure, length, domains, and suspicious patterns
                </p>
              </div>
              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
                <h4 className="font-semibold">ML Classification</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  Uses machine learning to classify URLs as safe or malicious
                </p>
              </div>
              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mx-auto">
                  <AlertTriangle className="h-6 w-6 text-purple-600" />
                </div>
                <h4 className="font-semibold">Risk Assessment</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  Provides detailed risk factors and confidence scores
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
