import { type NextRequest, NextResponse } from "next/server"

// Suspicious keywords commonly found in phishing URLs
const SUSPICIOUS_KEYWORDS = [
  "secure",
  "account",
  "update",
  "verify",
  "login",
  "signin",
  "banking",
  "paypal",
  "amazon",
  "microsoft",
  "google",
  "apple",
  "facebook",
  "suspended",
  "limited",
  "confirm",
  "validation",
  "security",
]

// Known legitimate domains (simplified list)
const LEGITIMATE_DOMAINS = [
  "google.com",
  "microsoft.com",
  "apple.com",
  "amazon.com",
  "paypal.com",
  "facebook.com",
  "twitter.com",
  "linkedin.com",
  "github.com",
  "stackoverflow.com",
]

interface URLFeatures {
  urlLength: number
  domainLength: number
  hasHttps: boolean
  hasSubdomains: number
  hasSuspiciousKeywords: boolean
  hasIpAddress: boolean
  hasShortener: boolean
  hasSpecialChars: number
}

function extractFeatures(url: string): URLFeatures {
  try {
    const urlObj = new URL(url)
    const domain = urlObj.hostname
    const path = urlObj.pathname + urlObj.search

    // Count subdomains
    const subdomains = domain.split(".").length - 2

    // Check for suspicious keywords
    const lowerUrl = url.toLowerCase()
    const hasSuspiciousKeywords = SUSPICIOUS_KEYWORDS.some((keyword) => lowerUrl.includes(keyword))

    // Check for IP address
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/
    const hasIpAddress = ipRegex.test(domain)

    // Check for URL shorteners
    const shorteners = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly"]
    const hasShortener = shorteners.some((shortener) => domain.includes(shortener))

    // Count special characters in path
    const specialChars = (path.match(/[!@#$%^&*()_+=[\]{}|;':",./<>?~`]/g) || []).length

    return {
      urlLength: url.length,
      domainLength: domain.length,
      hasHttps: urlObj.protocol === "https:",
      hasSubdomains: Math.max(0, subdomains),
      hasSuspiciousKeywords,
      hasIpAddress,
      hasShortener,
      hasSpecialChars: specialChars,
    }
  } catch (error) {
    // If URL parsing fails, return high-risk features
    return {
      urlLength: url.length,
      domainLength: 0,
      hasHttps: false,
      hasSubdomains: 0,
      hasSuspiciousKeywords: true,
      hasIpAddress: false,
      hasShortener: false,
      hasSpecialChars: 0,
    }
  }
}

function calculatePhishingScore(features: URLFeatures, url: string): { score: number; riskFactors: string[] } {
  let score = 0
  const riskFactors: string[] = []

  // URL length (longer URLs are more suspicious)
  if (features.urlLength > 100) {
    score += 0.2
    riskFactors.push("Unusually long URL")
  }

  // Domain length
  if (features.domainLength > 30) {
    score += 0.15
    riskFactors.push("Long domain name")
  }

  // HTTPS check
  if (!features.hasHttps) {
    score += 0.25
    riskFactors.push("No HTTPS encryption")
  }

  // Subdomain count
  if (features.hasSubdomains > 3) {
    score += 0.2
    riskFactors.push("Multiple subdomains")
  }

  // Suspicious keywords
  if (features.hasSuspiciousKeywords) {
    score += 0.3
    riskFactors.push("Contains suspicious keywords")
  }

  // IP address instead of domain
  if (features.hasIpAddress) {
    score += 0.4
    riskFactors.push("Uses IP address instead of domain name")
  }

  // URL shorteners
  if (features.hasShortener) {
    score += 0.25
    riskFactors.push("Uses URL shortening service")
  }

  // Special characters
  if (features.hasSpecialChars > 10) {
    score += 0.15
    riskFactors.push("Excessive special characters")
  }

  // Check against known legitimate domains
  try {
    const domain = new URL(url).hostname
    const isLegitimate = LEGITIMATE_DOMAINS.some(
      (legitDomain) => domain === legitDomain || domain.endsWith("." + legitDomain),
    )
    if (isLegitimate) {
      score = Math.max(0, score - 0.3)
    }
  } catch (error) {
    // URL parsing failed, increase score
    score += 0.2
    riskFactors.push("Invalid URL format")
  }

  return { score: Math.min(1, score), riskFactors }
}

export async function POST(request: NextRequest) {
  try {
    const { url } = await request.json()

    if (!url || typeof url !== "string") {
      return NextResponse.json({ error: "Valid URL is required" }, { status: 400 })
    }

    // Extract features from the URL
    const features = extractFeatures(url)

    // Calculate phishing score
    const { score, riskFactors } = calculatePhishingScore(features, url)

    // Determine if URL is phishing (threshold: 0.5)
    const isPhishing = score > 0.5
    const confidence = isPhishing ? score : 1 - score

    const result = {
      url,
      isPhishing,
      confidence,
      features: {
        urlLength: features.urlLength,
        domainLength: features.domainLength,
        hasHttps: features.hasHttps,
        hasSubdomains: features.hasSubdomains,
        hasSuspiciousKeywords: features.hasSuspiciousKeywords,
        hasIpAddress: features.hasIpAddress,
      },
      riskFactors,
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Phishing detection error:", error)
    return NextResponse.json({ error: "Failed to analyze URL" }, { status: 500 })
  }
}
