"""
Simple phishing detection model training script
This demonstrates how you could train a more sophisticated ML model
"""

import json
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import pickle

# Sample training data (in a real scenario, you'd have thousands of examples)
training_data = [
    # Legitimate URLs
    {"url": "https://www.google.com", "features": [18, 10, 1, 1, 0, 0, 0, 2], "label": 0},
    {"url": "https://github.com/user/repo", "features": [25, 10, 1, 0, 0, 0, 0, 3], "label": 0},
    {"url": "https://stackoverflow.com/questions", "features": [35, 16, 1, 0, 0, 0, 0, 4], "label": 0},
    {"url": "https://www.amazon.com/products", "features": [32, 10, 1, 1, 0, 0, 0, 3], "label": 0},
    {"url": "https://docs.python.org/3/", "features": [26, 15, 1, 1, 0, 0, 0, 2], "label": 0},
    
    # Phishing URLs (simulated examples)
    {"url": "http://secure-paypal-update.suspicious.com/login", "features": [48, 25, 0, 2, 1, 0, 0, 8], "label": 1},
    {"url": "https://amazon-security-alert.fake-domain.net/verify", "features": [52, 28, 1, 3, 1, 0, 0, 9], "label": 1},
    {"url": "http://192.168.1.100/microsoft-login", "features": [35, 13, 0, 0, 1, 1, 0, 5], "label": 1},
    {"url": "https://bit.ly/suspicious-link-here", "features": [32, 6, 1, 0, 1, 0, 1, 4], "label": 1},
    {"url": "http://google-account-suspended.malicious.org/confirm", "features": [55, 30, 0, 2, 1, 0, 0, 10], "label": 1},
]

def train_phishing_model():
    """Train a simple Random Forest model for phishing detection"""
    
    # Prepare data
    X = np.array([item["features"] for item in training_data])
    y = np.array([item["label"] for item in training_data])
    
    # Feature names for reference
    feature_names = [
        "url_length", "domain_length", "has_https", "subdomain_count",
        "suspicious_keywords", "has_ip", "has_shortener", "special_chars"
    ]
    
    print("Training phishing detection model...")
    print(f"Dataset size: {len(training_data)} samples")
    print(f"Features: {feature_names}")
    
    # Split data (with such a small dataset, we'll use most for training)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )
    
    # Train Random Forest model
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        random_state=42,
        class_weight='balanced'  # Handle class imbalance
    )
    
    model.fit(X_train, y_train)
    
    # Evaluate model
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"\nModel Performance:")
    print(f"Accuracy: {accuracy:.2f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=['Legitimate', 'Phishing']))
    
    # Feature importance
    print("\nFeature Importance:")
    for name, importance in zip(feature_names, model.feature_importances_):
        print(f"{name}: {importance:.3f}")
    
    # Save model (in a real app, you'd load this in your API)
    with open('phishing_model.pkl', 'wb') as f:
        pickle.dump(model, f)
    
    print("\nModel saved as 'phishing_model.pkl'")
    print("Note: This is a simplified example. In production, you'd need:")
    print("- Much larger training dataset (10k+ samples)")
    print("- More sophisticated features")
    print("- Cross-validation and hyperparameter tuning")
    print("- Regular model updates with new phishing patterns")

if __name__ == "__main__":
    train_phishing_model()
